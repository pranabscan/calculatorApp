package com.pranab.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import kotlin.math.pow

class MainActivity : AppCompatActivity() {
    private lateinit var editText :EditText
    private var number1 : Float =0.0f
    private var isplus : Boolean = false
    private var isminus : Boolean = false
    private var isDivide :Boolean =false
    private var ismultiply :Boolean =false
    private var isreminder :Boolean =false
    private var ispercentage :Boolean =false
    private var ispower :Boolean =false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editText=findViewById(R.id.number_edit_text)
    }
    fun operationFunction(view : View){

        when(view.id){
           R.id.button_one ->{
               numberClicked(1)
           }
            R.id.button_two ->{
                numberClicked(2)
            }
            R.id.button_three ->{
                numberClicked(3)
            }
            R.id.button_four ->{
                numberClicked(4)
            }
            R.id.button_five ->{
                numberClicked(5)
            }
            R.id.button_six ->{
                numberClicked(6)
            }
            R.id.button_seven ->{
                numberClicked(7)
            }
            R.id.button_eight ->{
                numberClicked(8)
            }
            R.id.button_nine ->{
                numberClicked(9)
            }
            R.id.button_zero ->{
                numberClicked(0)
            }
            R.id.button_dot ->{
                val number=editText.text.toString() + "."
                editText.setText(number)
            }
            R.id.button_clear ->{
                editText.setText("")
            }
            R.id.button_plus ->{
                plusClicked()
            }
            R.id.button_minus ->{
                minusClicked()
            }
            R.id.button_Divide ->{
                divideClicked()
            }
            R.id.button_multiply ->{
                multiplyClicked()
            }
            R.id.button_reminder ->{
                reminderClicked()
            }
            R.id.button_percentage ->{
                percentageClicked()
            }
            R.id.button_power ->{
                powerClicked()
            }
            R.id.button_equal ->{
                 equalClicked()
            }
        }
    }
    private fun numberClicked(numberClicked : Int){
        val number=editText.text.toString() + numberClicked.toString()
        editText.setText(number)
    }
    private fun plusClicked(){
        number1=editText.text.toString().toFloat()
        editText.setText("")
        isplus=true
    }
    private fun minusClicked(){
        number1=editText.text.toString().toFloat()
        editText.setText("")
        isminus=true
    }
    private fun divideClicked(){
        number1=editText.text.toString().toFloat()
        editText.setText("")
        isDivide=true
    }
    private fun multiplyClicked(){
        number1=editText.text.toString().toFloat()
        editText.setText("")
        ismultiply=true
    }
    private fun reminderClicked(){
        number1=editText.text.toString().toFloat()
        editText.setText("")
        isreminder=true
    }
    private fun percentageClicked(){
        number1=editText.text.toString().toFloat()
        editText.setText("")
        ispercentage=true
    }
    private fun powerClicked(){
        number1=editText.text.toString().toFloat()
        editText.setText("")
        ispower=true
    }
    private fun equalClicked(){
        when {
            isplus -> {
                plus()
            }
            isminus -> {
               minus()
            }
            isDivide -> {
               divide()
            }
            ismultiply -> {
                multiply()
            }
            isreminder -> {
                reminder()
            }
            ispercentage -> {
                percentage()
            }
            ispower -> {
                power()
            }
        }
    }
    private  fun plus(){
        val number2=editText.text.toString().toFloat()
        val result=number1+number2
        editText.setText(result.toString())
        isplus=false
    }
    private fun minus(){
        val number2=editText.text.toString().toFloat()
        val result=number1-number2
        editText.setText(result.toString())
        isminus=false
    }
    private fun divide(){
        val number2=editText.text.toString().toFloat()
        val result=number1/number2
        editText.setText(result.toString())
        isDivide=false
    }
    private fun multiply(){
        val number2=editText.text.toString().toFloat()
        val result=number1*number2
        editText.setText(result.toString())
        ismultiply=false
    }
    private fun reminder(){
        val number2=editText.text.toString().toFloat()
        val result=number1%number2
        editText.setText(result.toString())
        isreminder=false
    }
    private fun percentage(){
        val number2=editText.text.toString().toFloat()
        val result=(number1/number2)*100
        editText.setText(result.toString())
        ispercentage=false
    }
    private fun power(){
        val number2=editText.text.toString().toFloat()
        val result=number1.pow(number2)
        editText.setText(result.toString())
        ispower=false
    }

}